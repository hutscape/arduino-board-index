# Custom Arduino Hutscape boards

This repository includes custom Arduino boards for Hutscape.
